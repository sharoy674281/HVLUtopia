import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import matplotlib.patches as mpatches
import numpy as np
import math
from Utils import calculate_average, CalcPointValue

class Plotter:
    def __init__(self, kron_nox_year, nord_nox_year, markert_plass_nox_year, asfalt_year, coordinates):
        self.kron_nox_year = kron_nox_year
        self.nord_nox_year = nord_nox_year
        self.markert_plass_nox_year = markert_plass_nox_year
        self.asfalt_year = asfalt_year
        self.coordinates = coordinates
        self.marked_point = coordinates['Markert plass']
        self.current_data_type = 'NOX'
        self.days_interval = (0, 365)

        self.fig = plt.figure(figsize=(13, 5))
        self.axNok = self.fig.add_axes((0.05, 0.15, 0.45, 0.8))
        self.axBergen = self.fig.add_axes((0.5, 0.05, 0.5, 0.9))

        self.plot_graph()

    def draw_circles_stations(self):
        for patch in self.axBergen.patches:
            patch.remove()
        for color, coord in zip(['blue', 'red', 'orange'], ['Nordnes', 'Kronstad', 'Markert plass']):
            if coord == 'Markert plass':
                circle = mpatches.Circle(self.marked_point, 50, color=color, alpha=0.5)
            else:
                circle = mpatches.Circle(self.coordinates[coord], 50, color=color, alpha=0.5)
            self.axBergen.add_patch(circle)

    def plot_graph(self):
        self.axNok.cla()
        self.axBergen.cla()

        nord_nox = self.nord_nox_year[self.days_interval[0]:self.days_interval[1]]
        kron_nox = self.kron_nox_year[self.days_interval[0]:self.days_interval[1]]
        markert_plass_nox = self.markert_plass_nox_year[self.days_interval[0]:self.days_interval[1]]

        if self.current_data_type == 'Asfaltstøv':
            nord_nox = self.asfalt_year[self.days_interval[0]:self.days_interval[1]]
            kron_nox = self.asfalt_year[self.days_interval[0]:self.days_interval[1]]
            markert_plass_nox = self.asfalt_year[self.days_interval[0]:self.days_interval[1]]

        days = len(nord_nox)
        list_days = np.arange(1, days + 1)

        markert_plass_nox = [
            CalcPointValue(nord_nox[i], kron_nox[i], markert_plass_nox[i], self.marked_point, self.coordinates)
            for i in range(days)
        ]

        self.axNok.plot(list_days, nord_nox, 'blue', label='Nordnes')
        self.axNok.plot(list_days, kron_nox, 'red', label='Kronstad')
        self.axNok.plot(list_days, markert_plass_nox, 'orange', label='Markert plass')

        average, relative_to_kronstad = calculate_average(nord_nox, kron_nox, markert_plass_nox)
        self.axNok.set_title(
            f"{self.current_data_type} verdier (Snitt: {average:.2f}, Relativ til Kronstad: {relative_to_kronstad:.2f}%)"
        )

        self.axNok.set_xticks(np.linspace(1, days, num=12))
        self.axNok.set_xticklabels(np.linspace(1, 12, num=12, dtype=int))
        self.axNok.legend()
        self.axNok.grid(linestyle='--')

        img = mpimg.imread("Bergen.jpg")
        self.axBergen.imshow(img)
        self.draw_circles_stations()
