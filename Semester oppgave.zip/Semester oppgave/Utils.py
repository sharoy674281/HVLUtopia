import math
import numpy as np


def calculate_average(nord_nox, kron_nox, markert_plass_nox):
    average_nord = np.mean(nord_nox)
    average_kron = np.mean(kron_nox)
    average_markert_plass = np.mean(markert_plass_nox)
    overall_average = (average_nord + average_kron + average_markert_plass) / 3
    return overall_average, (overall_average / average_kron) * 100

def CalcPointValue(valN, valK, valMarkert_plass, marked_point, coordinates):
    distNordnes = math.dist(coordinates['Nordnes'], marked_point)
    distKronstad = math.dist(coordinates['Kronstad'], marked_point)
    distMarkert_plass = math.dist(coordinates['Markert plass'], marked_point)

    val = (1 - distKronstad / (distKronstad + distNordnes)) * valK
    val += (1 - distNordnes / (distKronstad + distNordnes)) * valN
    val += (1 - distMarkert_plass / (distMarkert_plass + distNordnes)) * valMarkert_plass
    return val
