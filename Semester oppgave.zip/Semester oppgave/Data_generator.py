import random
from random import randint

def GenereateRandomYearDataList(intensity: float, seed: int = 0) -> list:
    if seed != 0:
        random.seed(seed)
    centervals = [200, 150, 100, 75, 75, 75, 50, 75, 100, 150, 200, 250, 300]
    centervals = [x * intensity for x in centervals]
    nox = centervals[0]
    inc = True
    noxList = []
    for index in range(1, 365):
        if randint(1, 100) > 50:
            inc = not inc
        center = centervals[int(index / 30)]
        dx = min(2.0, max(0.5, nox / center))
        nox = nox + randint(1, 5) / dx if inc else nox - randint(1, 5) * dx
        nox = max(10, nox)
        noxList.append(nox)
    return noxList

def generate_data():
    kron_nox_year = GenereateRandomYearDataList(intensity=1.0, seed=2)
    nord_nox_year = GenereateRandomYearDataList(intensity=0.3, seed=1)
    markert_plass_nox_year = GenereateRandomYearDataList(intensity=0.7, seed=3)
    asfalt_year = GenereateRandomYearDataList(intensity=0.8, seed=5)
    return kron_nox_year, nord_nox_year, markert_plass_nox_year, asfalt_year
