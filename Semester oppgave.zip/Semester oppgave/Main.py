import matplotlib.pyplot as plt
from matplotlib.widgets import RangeSlider, RadioButtons
from Data_generator import generate_data
from Plotter import Plotter

def update(val):
    start_day, end_day = slider.val
    if start_day < end_day:
        plotter.days_interval = (int(start_day) - 1, int(end_day))
        plotter.plot_graph()

def on_type_change(label):
    plotter.current_data_type = label
    plotter.plot_graph()

def on_click(event):
    if event.inaxes == plotter.axBergen:
        plotter.marked_point = (event.xdata, event.ydata)
        plotter.plot_graph()

kron_nox_year, nord_nox_year, markert_plass_nox_year, asfalt_year = generate_data()

coordinates = {
    'Nordnes': (200, 150),
    'Kronstad': (650, 720),
    'Markert plass': (415, 490)
}

plotter = Plotter(kron_nox_year, nord_nox_year, markert_plass_nox_year, asfalt_year, coordinates)

ax_slider = plotter.fig.add_axes((0.05, 0.05, 0.4, 0.05))
slider = RangeSlider(ax_slider, 'Dag Intervall', valmin=1, valmax=365, valinit=(1, 365))

slider.on_changed(update)
ax_radio = plotter.fig.add_axes((0.4, 0.6, 0.1, 0.1))
radio_button_type = RadioButtons(ax_radio, ('NOX', 'Asfaltstøv'))
radio_button_type.on_clicked(on_type_change)

cid = plotter.fig.canvas.mpl_connect('button_press_event', on_click)
plt.show()
